package com.coderhouse.ClientAPIRest;


import com.coderhouse.ClientAPIRest.model.Cliente;
import com.coderhouse.ClientAPIRest.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDate;
import java.util.Optional;

@SpringBootApplication
public class ClientAPI implements CommandLineRunner {

	@Autowired
	private ClienteRepository clientRepository;



	public static void main(String[] args) {
		SpringApplication.run(ClientAPI.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Server listening. Access H2 on: http://localhost:8888/h2-console");

		try {
			Cliente cliente = new Cliente();
			cliente.setNombre("Luciano");
			cliente.setApellido("Carini");
			cliente.setFechaNacimiento(LocalDate.of(2005, 2, 4));
			this.clientRepository.save(cliente);

			Optional<Cliente> clienteGuardado = this.clientRepository.findById(1L);


			System.out.println(clienteGuardado);


		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}


}
