package com.coderhouse.ClientAPIRest.controller;

import com.coderhouse.ClientAPIRest.model.Cliente;
import com.coderhouse.ClientAPIRest.model.ClienteDTO;
import com.coderhouse.ClientAPIRest.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cliente")
public class ClienteController {
    private final ClienteService clienteService;

    @Autowired
    public ClienteController(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @PostMapping
    public ResponseEntity<ClienteDTO> crearCliente(@RequestBody ClienteDTO clienteDTO) {
        Cliente cliente = clienteService.crearCliente(clienteDTO.getNombre(), clienteDTO.getApellido(), clienteDTO.getFechaNacimiento());
        int edad = clienteService.calcularEdad(cliente.getFechaNacimiento());

        ClienteDTO responseDTO = new ClienteDTO();
        responseDTO.setNombre(cliente.getNombre());
        responseDTO.setApellido(cliente.getApellido());
        responseDTO.setEdad(edad);

        return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClienteDTO> obtenerCliente(@PathVariable int id) {
        // Lógica para obtener el cliente de la base de datos por su id
        Cliente cliente = new Cliente(); // Supongamos que se obtiene el cliente de alguna manera

        int edad = clienteService.calcularEdad(cliente.getFechaNacimiento());

        ClienteDTO clienteDTO = new ClienteDTO();
        clienteDTO.setNombre(cliente.getNombre());
        clienteDTO.setApellido(cliente.getApellido());
        clienteDTO.setEdad(edad);

        return ResponseEntity.ok(clienteDTO);
    }
}
