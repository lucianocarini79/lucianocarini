package com.coderhouse.ClientAPIRest.repository;

import com.coderhouse.ClientAPIRest.model.Cliente;
import org.springframework.data.repository.CrudRepository;

public interface ClienteRepository extends CrudRepository<Cliente, Long> {
    // Métodos adicionales si los necesitas
}
